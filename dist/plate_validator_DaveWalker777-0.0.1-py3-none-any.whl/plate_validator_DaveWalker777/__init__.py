from .validator import validate_plate
